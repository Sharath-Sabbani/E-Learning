# TCS iON RIO-45 Internship

Build a project named Learning Platform Configuration of Product Web Page using HTML, CSS, Bootstrap.

### Project Objective

```
The objective of this project is to develop a web page for learning platform.
```

### Project Guidelines

```
- First create a HTML pagepage of website. 
- Second construct a HTML page in to different sections.
- Make sections like Banner, Inroduction, Insight card, Career fitment report, Paid offering by compass school.
- Link CSS file with HTML page. 
```

### Project Outcome

```
- Online learning for students.
```

### Faculty Feedback

<p align="center">
  <kbd><img src="https://github.com/shubhadeepmandal394/tcs-remote-internship/blob/main/Project%20Report/Faculty%20Feedback.png" width="1000" height="300"></kbd>
</p>

### Important Links

- Run this website directly in your Browser: [Browser Link](https://niteshraghav22.github.io/TCS-iON-Rio-45-internship/)
- View the Internship Certificate: [Certificate Link](https://drive.google.com/file/d/104cPFdHc5mSfArg6lQ7y2JyuSb4pnGfJ/view)
- View the Internship Report: [Report Link](https://drive.google.com/file/d/1058aU-5JUZ4dxRP5kB2Q7HrJd-unINTZ/view)






